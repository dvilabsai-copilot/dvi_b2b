<?php

/*
* JACKUS - An In-house Framework for TDS Apps
*
* Author: Touchmark Descience Private Limited. 
* https://touchmarkdes.com
* Version 4.0.1
* Copyright (c) 2010-2023 Touchmark Descience Pvt Ltd
*
*/

include_once('../../jackus.php');

if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest')) : //CHECK AJAX REQUEST

    if ($_GET['type'] == 'show_image') :
        $driver_ID = $_GET['driver_ID'];
?>

<div class="card-body bulk-upload-body" id="bulk-upload-body">
    <div class="d-flex justify-content-between">
        <h4>Upload Documents</h4>
        <div>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#upload_document_modal">
                + Upload
            </button>
        </div>
    </div>

    <div class="row">
        <?php if ($driver_ID != '') :

                    // echo "SELECT `driver_code`, `driver_name` FROM `dvi_driver_details` WHERE `deleted` = '0' AND `driver_id` = '$driver_ID'";
                    // exit;

                    $select_driver_list = sqlQUERY_LABEL("SELECT `driver_code`, `driver_name` FROM `dvi_driver_details` WHERE `deleted` = '0' AND `driver_id` = '$driver_ID'") or die("#1-UNABLE_TO_COLLECT_DRIVER_DETAILS:" . sqlERROR_LABEL());

                    while ($fetch_driver_data = sqlFETCHARRAY_LABEL($select_driver_list)) :
                        $counter++;
                        $driver_code = $fetch_driver_data['driver_code'];
                        $driver_name = $fetch_driver_data['driver_name'];
                    endwhile;

                    // echo "SELECT `driver_document_details_id`, `driver_id`, `document_type`, `driver_document_name`, `status` FROM `dvi_driver_document_details` WHERE `deleted` = '0' AND `driver_id` = '$driver_ID' ORDER BY 'document_type' ASC";
                    // exit;


                    $select_list = sqlQUERY_LABEL("SELECT `driver_document_details_id`, `driver_id`, `document_type`, `driver_document_name`, `status` FROM `dvi_driver_document_details` WHERE `deleted` = '0' AND `driver_id` = '$driver_ID' ORDER BY 'document_type' ASC") or die("#1-UNABLE_TO_COLLECT_VEHICAL_COST_LIST:" . sqlERROR_LABEL());

                    $num_row_document = sqlNUMOFROW_LABEL($select_list);
                    if ($num_row_document > 0) :
                        $btn_next_step = "Save & Continue";
                        while ($fetch_data = sqlFETCHARRAY_LABEL($select_list)) :
                            $counter++;
                            $driver_document_details_id = $fetch_data['driver_document_details_id'];
                            $driver_id = $fetch_data['driver_id'];
                            $document_type = $fetch_data['document_type'];
                            $driver_document_name = $fetch_data['driver_document_name'];
                ?>
        <div class="col-md-3  my-2">
            <div class="my-2">
                <label><?= getDOCUMENTTYPE($document_type, 'label'); ?></label>
            </div>

            <a href="uploads/driver_gallery/<?= $driver_name . $driver_code; ?>/<?= $driver_document_name; ?>"
                class="fs-6" download>
                <img src="../head/uploads/driver_gallery/<?= $driver_name . $driver_code; ?>/<?= $driver_document_name; ?>"
                    class="room-details-shadow  cursor rounded" width="200px" height="120px">
            </a>
        </div>
        <?php
                        endwhile;

                    else :
                        $btn_next_step = "Skip & Continue";
                        ?>
        <div class="text-center mt-2">
            <svg xmlns="http://www.w3.org/2000/svg" height="150" version="1.1" viewBox="-23 0 512 512" width="150">
                <g id="surface1">
                    <path
                        d="M 337.953125 230.601562 C 404.113281 239.886719 455.015625 296.65625 455.015625 365.378906 C 455.015625 440.503906 394.082031 501.4375 318.957031 501.4375 C 267.3125 501.4375 222.277344 472.625 199.335938 430.152344 C 188.878906 410.839844 182.902344 388.75 182.902344 365.273438 C 182.902344 290.148438 243.835938 229.214844 318.957031 229.214844 C 325.363281 229.320312 331.660156 229.75 337.953125 230.601562 Z M 337.953125 230.601562 "
                        style="stroke:none;fill-rule:nonzero;fill:#fff;fill-opacity:1;" />
                    <path
                        d="M 337.953125 230.601562 C 331.765625 229.75 325.363281 229.320312 318.957031 229.320312 C 243.835938 229.320312 182.902344 290.253906 182.902344 365.378906 C 182.902344 388.855469 188.878906 410.945312 199.335938 430.257812 L 199.121094 430.367188 L 57.199219 430.367188 C 31.265625 430.367188 10.242188 409.34375 10.242188 383.414062 L 10.242188 57.730469 C 10.242188 31.800781 31.265625 10.777344 57.199219 10.777344 L 229.429688 10.777344 L 229.429688 88.464844 C 229.429688 108.523438 245.648438 124.746094 265.710938 124.746094 L 337.953125 124.746094 Z M 337.953125 230.601562 "
                        style=" stroke:none;fill-rule:nonzero;fill:#fff;fill-opacity:1;" />
                    <path
                        d="M 229.429688 10.777344 L 337.953125 124.746094 L 265.710938 124.746094 C 245.648438 124.746094 229.429688 108.523438 229.429688 88.464844 Z M 229.429688 10.777344 "
                        style=" stroke:none;fill-rule:nonzero;fill:#fff;fill-opacity:1;" />
                    <path
                        d="M 348.945312 221.640625 L 348.945312 124.746094 C 348.945312 121.96875 347.664062 119.410156 345.851562 117.382812 L 237.21875 3.308594 C 235.191406 1.175781 232.308594 0 229.429688 0 L 57.199219 0 C 25.398438 0 0 25.929688 0 57.730469 L 0 383.414062 C 0 415.214844 25.398438 440.71875 57.199219 440.71875 L 193.148438 440.71875 C 219.609375 485.535156 267.203125 512 318.960938 512 C 399.847656 512 465.6875 446.265625 465.6875 365.273438 C 465.6875 329.632812 452.988281 295.375 429.511719 268.59375 C 408.277344 244.476562 379.890625 228.042969 348.945312 221.640625 Z M 240.101562 37.457031 L 312.984375 114.179688 L 265.710938 114.179688 C 251.625 114.179688 240.097656 102.550781 240.097656 88.464844 L 240.097656 37.457031 Z M 21.34375 383.414062 L 21.34375 57.730469 C 21.34375 37.667969 37.242188 21.34375 57.199219 21.34375 L 218.757812 21.34375 L 218.757812 88.464844 C 218.757812 114.394531 239.78125 135.523438 265.710938 135.523438 L 327.605469 135.523438 L 327.605469 218.863281 C 324.402344 218.757812 321.839844 218.332031 319.066406 218.332031 C 281.824219 218.332031 247.570312 232.628906 221.746094 255.039062 L 86.222656 255.039062 C 80.355469 255.039062 75.550781 259.839844 75.550781 265.710938 C 75.550781 271.582031 80.351562 276.382812 86.222656 276.382812 L 201.898438 276.382812 C 194.320312 287.054688 188.023438 297.726562 183.117188 309.464844 L 86.222656 309.464844 C 80.355469 309.464844 75.550781 314.265625 75.550781 320.132812 C 75.550781 326.003906 80.351562 330.804688 86.222656 330.804688 L 176.179688 330.804688 C 173.511719 341.476562 172.125 353.320312 172.125 365.167969 C 172.125 383.839844 175.644531 402.300781 182.476562 419.375 L 57.199219 419.375 C 37.242188 419.375 21.34375 403.367188 21.34375 383.414062 Z M 318.960938 490.765625 C 272.96875 490.765625 230.601562 465.582031 208.621094 425.136719 C 198.695312 406.890625 193.46875 386.292969 193.46875 365.378906 C 193.46875 296.230469 249.703125 239.992188 318.851562 239.992188 C 324.722656 239.992188 330.589844 240.421875 336.351562 241.167969 C 366.019531 245.328125 393.335938 260.054688 413.183594 282.679688 C 433.246094 305.515625 444.238281 334.859375 444.238281 365.378906 C 444.34375 434.527344 388.109375 490.765625 318.960938 490.765625 Z M 318.960938 490.765625"
                        style="stroke:none;fill-rule:nonzero;fill-opacity:1;" fill="#f4f4f7" data-original="#000000" />
                    <path
                        d="M 86.222656 223.027344 L 194.320312 223.027344 C 200.191406 223.027344 204.992188 218.222656 204.992188 212.355469 C 204.992188 206.484375 200.191406 201.683594 194.320312 201.683594 L 86.222656 201.683594 C 80.355469 201.683594 75.550781 206.484375 75.550781 212.355469 C 75.550781 218.222656 80.355469 223.027344 86.222656 223.027344 Z M 86.222656 223.027344 "
                        style="stroke:none;fill-rule:nonzero;fill-opacity:1;" fill="#f4f4f7" data-original="#000000" />
                    <path
                        d="M 326.535156 286.625 C 324.507812 284.492188 321.734375 283.210938 318.746094 283.210938 C 315.757812 283.210938 312.984375 284.492188 310.957031 286.625 L 248.425781 353.746094 C 244.367188 358.015625 244.6875 364.84375 248.957031 368.792969 C 250.984375 370.714844 253.652344 371.675781 256.214844 371.675781 C 259.09375 371.675781 262.082031 370.5 264.21875 368.257812 L 308.394531 320.984375 L 308.394531 437.515625 C 308.394531 443.382812 313.199219 448.1875 319.066406 448.1875 C 324.9375 448.1875 329.738281 443.382812 329.738281 437.515625 L 329.738281 320.988281 L 373.597656 368.261719 C 377.652344 372.527344 384.269531 372.847656 388.644531 368.792969 C 392.910156 364.738281 393.125 358.015625 389.175781 353.746094 Z M 326.535156 286.625 "
                        style="stroke:none;fill-rule:nonzero;fill-opacity:1;" fill="#f4f4f7" data-original="#000000" />
                </g>
            </svg>
        </div>
        <?php
                    endif;
                    ?>
        <?php endif; ?>
    </div>

</div>
<input type="hidden" name="hidden_driver_ID" id="hidden_driver_ID" class="form-control" value="<?= $driver_ID; ?>" />
<div class=" mt-5">
    <div class="d-flex justify-content-between py-3">
        <div>
            <a href="driver.php?route=add&formtype=basic_info" class="btn btn-label-github waves-effect ps-3"><svg
                    xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-narrow-left me-1"
                    width="20" height="20" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                    stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <path d="M5 12l14 0"></path>
                    <path d="M5 12l4 4"></path>
                    <path d="M5 12l4 -4"></path>
                </svg>Back
            </a>
        </div>
        <div>
            <a href="driver.php?route=add&formtype=renewal_history&id=<?= $driver_ID; ?>" type="button"
                class="btn btn-primary waves-effect waves-light"><?= $btn_next_step; ?><svg
                    xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-narrow-right ms-1"
                    width="20" height="20" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                    stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <path d="M5 12l14 0"></path>
                    <path d="M15 16l4 -4"></path>
                    <path d="M15 8l4 4"></path>
                </svg></a>
        </div>
    </div>
</div>
<?php
    endif;
endif;
?>